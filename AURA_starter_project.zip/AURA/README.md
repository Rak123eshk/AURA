# AURA Android starter (prototype)

This is a minimal native Android starter project for AURA.


## Current prototype
- Basic dark AURA screen
- Tap-to-speak using Android speech recognition
- Text-to-speech response (currently a placeholder, not an AI answer)
- Foreground background-service prototype with persistent notification


## Not implemented yet
- Actual AI/API connection
- True wake phrase detection ("Hey AURA")
- Continuous microphone listening
- Reliable screen-off wake behavior
- Memory, web search, phone actions


## Build
Open this folder in Android Studio and sync Gradle. Use Android SDK 35 and JDK 17 compatible with Android Gradle Plugin 8.7.3. Build/install APK from Android Studio.


## Safety/privacy
A foreground microphone service requires clear notification and permission. Keep API keys on a backend, not inside the APK. Android/OEM restrictions can interrupt background operation.
