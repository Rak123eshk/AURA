package com.aura.assistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

public class AuraListeningService extends Service {
    private static final String CHANNEL = "aura_background";
    @Override public void onCreate() { super.onCreate(); createChannel(); }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        Notification notification;
        if (Build.VERSION.SDK_INT >= 26) {
            notification = new Notification.Builder(this, CHANNEL).setContentTitle("AURA is active")
                .setContentText("Background prototype running. Wake-word listening is not implemented yet.")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).build();
        } else {
            notification = new Notification.Builder(this).setContentTitle("AURA is active")
                .setContentText("Background prototype running.").setSmallIcon(android.R.drawable.ic_btn_speak_now).build();
        }
        startForeground(1001, notification);
        return START_STICKY;
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "AURA background assistant", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
