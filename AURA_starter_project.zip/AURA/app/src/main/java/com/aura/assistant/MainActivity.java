package com.aura.assistant;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.widget.Button;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Locale;


public class MainActivity extends Activity {
    private TextView status, reply;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private static final int SPEECH_REQUEST = 21;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status); reply = findViewById(R.id.reply);
        Button talk = findViewById(R.id.talkButton), background = findViewById(R.id.backgroundButton);
        tts = new TextToSpeech(this, result -> { if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("en", "IN")); });
        talk.setOnClickListener(v -> startVoiceInput());
        background.setOnClickListener(v -> {
            Intent service = new Intent(this, AuraListeningService.class);
            try { startForegroundService(service); status.setText("Background service started (prototype; not wake-word listening yet)."); }
            catch (Exception e) { status.setText("Could not start background service: " + e.getMessage()); }
        });
    }
    private void startVoiceInput() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status.setText("Speech recognition is not available on this device."); return; }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to AURA");
        startActivityForResult(intent, SPEECH_REQUEST);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SPEECH_REQUEST && resultCode == RESULT_OK && data != null) {
            ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (matches != null && !matches.isEmpty()) {
                String heard = matches.get(0); reply.setText("You said: " + heard);
                String answer = "I heard you say: " + heard + ". AURA's AI connection is the next build step.";
                status.setText("Voice recognized"); if (tts != null) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "aura-reply");
            }
        }
    }
    @Override protected void onDestroy() { if (tts != null) tts.shutdown(); super.onDestroy(); }
}
